# TelegramStreamT.Live (Vercel-ready)

Мобильный фронт (Next.js + Tailwind) + серверлесс Telegram-бот (вебхук).

## Установка
```bash
npm i
```

Создай или отредактируй `.env`:
```
BOT_TOKEN=8448723827:AAG3XYmczWOkQJvYq9zyqdBEzM3yAYig7tU
DOMAIN=https://www.telegramstreamt.live
```

## Локально (через Vercel CLI)
```bash
npm i -g vercel
vercel dev
```

## Деплой
1) Подключи репозиторий к Vercel
2) В Settings → Environment Variables добавь BOT_TOKEN и DOMAIN
3) Открой: `https://www.telegramstreamt.live/api/setup` — установит вебхук на `/api/bot`

## WebApp
Открой бота и отправь `/start` — появится кнопка «Открыть TLive 🚀».
